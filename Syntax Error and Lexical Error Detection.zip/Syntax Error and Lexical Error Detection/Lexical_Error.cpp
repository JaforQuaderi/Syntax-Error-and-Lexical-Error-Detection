/// Project Name- "Lexical Error and Syntax Error Detection"
/// This .cpp File Contains - "Lexical Error Detection"
/// Submitted By- "Shah Jafor Sadeek Quaderi"  :  ID-"2014-2-60-075"
///               "Pritam Datta"               :  ID-"2014-2-60-078"
///               "Mohd. Rasadin"              :  ID-"2014-2-60-039"
/// CSE- 375 (Compiler Design)
/// Section - 1
/// Group - 6
/// Reference- This Project Successfully Is Compiled On Visual Stdio 2017 of Fahim Shaharier Rasel's PC.



/// Declaring Necessary Header Files

#include<cstdio>
#include<cstring>
#include<iostream>

using namespace std;

#define stringLength 50     /// Defining String Length Of String

int main()
{
    printf("..................................................................\n");
    printf("      Project Name- Lexical Error and Syntax Error Detection\n");
    printf("..................................................................\n\n");
    printf("This .cpp File Contains - Lexical Error Detection\n");
    printf(".........................\n\n");
    printf("Submitted By-\n");
    printf(".............\n");
    printf("              Shah Jafor Sadeek Quaderi  :  ID- 2014-2-60-075\n");
    printf("              Pritam Datta               :  ID- 2014-2-60-078\n");
    printf("              Mohd. Rasadin              :  ID- 2014-2-60-039\n\n");
    printf("CSE- 375 (Compiler Design)\n");
    printf("....\n");
    printf("Section - 1\n");
    printf(".........\n");
    printf("Group - 6\n");
    printf(".......\n");
    printf("Reference- This Project Successfully Is Compiled On Visual Studio 2017 of\n");
    printf(".......... Fahim Shaharier Rasel's PC\n\n\n");
    printf("- - - - - - - - - - - - - - - - - - - - - - - - - - -\n");
    printf("  Additional Information: Type 'end' For Termination \n");
    printf("- - - - - - - - - - - - - - - - - - - - - - - - - - -\n\n");



    char str[stringLength]; /// Declaring A String
    int flag = 0;           /// Declaring A Flag Variable For Using As Temporary


    /// Taking Tokens On String Array, Considering Few Values In Array For Describing Project'a Example

    string numberTokens[19] = {"0","1","2","3","4","5","6","7","8","9","-1",
                                "-2","-3","-4","-5","-6","-7","-8","-9"};
    string letterTokens[52] = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p",
                               "q","r","s","t","u","v","w","x","y","z","A","B","C","D","E","F","G","H",
                               "I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};

    string comparisonId[9] = {"<",">",">=","<=","!=","=","==","&&","||"};
    string conditionalStatement[6] = {"if","else","else if","break","continue","while"};
    string operatorSymbol[7] = {"+","-","*","/","%","++","--"};
    string constantValuesName[16] = {"pi","Pi","epsilon","Epsilon","epsilon naught","Epsilon naught",
                                    "Epsilon Naught","planck constant","Planck constant",
                                    "Planck Constant","gravitational constant",
                                    "gravitational Constant","Gravitational Constant","gravity","Gravity",
                                    "atm"};

    string constantValues[16] = {"3.1416","3.1416","8.8541e-12","8.8541e-12","8.8541e-12",
                                "8.8541e-12","8.8541e-12","6.6261e-34","6.6261e-34","6.6261e-34",
                                "6.6471e-11","6.6471e-11","6.6471e-11","9.81","9.81","101325"};


INPUT:       /// Using Input As A Loop For Inputing Values From User

    while(1)
    {
        printf("\n\n\n");
        printf("--------------\n");
        printf("Enter Input:\n");
        printf("--------------\n\n");
        gets(str);                  /// Taking String As String From User
        fflush(stdin);              /// Clearing Buffer On Input String

        if(strcmp(str,"end")==0)    /// Program Termination Condition
        {
            printf("\n\n");
            printf("Program Terminated\n\n");
            return 0;   /// Program Terminated And Returning 0
        }

        for(int i=0; i<19; i++)
        {
            if(str == numberTokens[i])      /// Comparing String With Number Token For Detecting Lexical Error
            {
                printf("\nNo Lexical Error Found In Input:  %s\n\n\n\n",str);
                flag = 1;           /// If No Error Found, Flag Value's Turns To 0 to 1
                goto INPUT;         /// Go To Take Input Again
            }
            else
            {
                flag = 0;           /// If Any Error Found, Flag Value's Remains 0 .
            }
        }


        for(int i=0; i<52; i++)
        {
            if(str == letterTokens[i])      /// Comparing String With Letter Token For Detecting Lexical Error
            {
                printf("\nNo Lexical Error Found In Input:  %s\n\n\n\n",str);
                flag = 1;
                goto INPUT;
            }
            else
            {
                flag = 0;
            }
        }


        for(int i=0; i<9; i++)
        {
            if(str == comparisonId[i])     /// Comparing String With Comparison Id For Detecting Lexical Error
            {
                printf("\nNo Lexical Error Found In Input:  %s\n\n\n\n",str);
                flag = 1;
                goto INPUT;
            }
            else
            {
                flag = 0;
            }
        }


        for(int i=0; i<6; i++)
        {
            if(str == conditionalStatement[i])      /// Matching String With Conditional Statement For Detecting Lexical Error
            {
                printf("\nNo Lexical Error Found In Input:  %s\n\n\n\n",str);
                flag = 1;
                goto INPUT;
            }
            else
            {
                flag = 0;
            }
        }

        for(int i=0; i<7; i++)
        {
            if(str == operatorSymbol[i])        /// Matching String With Operator Symbol For Detecting Lexical Error
            {
                printf("\nNo Lexical Error Found In Input:  %s\n\n\n\n",str);
                flag = 1;
                goto INPUT;
            }
            else
            {
                flag = 0;
            }
        }

        for(int i=0; i<16; i++)
        {
            if(str == constantValuesName[i])        /// Matching String With Constant Values Name For Detecting Lexical Error
            {
                printf("\nNo Lexical Error Found In Input:   %s ",str);
                cout << " ( " <<constantValues[i] << " )";
                printf("\n\n\n\n");
                flag = 1;
                goto INPUT;
            }
            else
            {
                flag = 0;
            }
        }

        for(int i=0; i<16; i++)
        {
            if(str == constantValues[i])        /// Matching String With Constant Value For Detecting Lexical Error
            {
                printf("\nNo Lexical Error Found In Input:   %s ",str);
                cout << " ( " <<constantValuesName[i] << " )";
                printf("\n\n\n\n");
                flag = 1;
                goto INPUT;
            }
            else
            {
                flag = 0;
            }
        }


        if(flag == 0)       /// Comparing The Value Of Flag With 0
        {
            printf("\nLexical Error Found In Input:  %s\n\n",str);      /// If Flag Value Is Equal To 0 Then It Shows Lexical Error
        }

        printf("\n\n\n");
        fflush(stdin);      /// Again Clearing Buffer
    }

    printf("\n\n");
    return 0;       /// Terminating Program With Returning 0
}
