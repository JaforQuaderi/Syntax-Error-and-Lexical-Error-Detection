/// Project Name - "Lexical Error and Syntax Error Detection"
/// This .cpp file Contains - "Syntax Error Detection"
/// Submitted By- "Shah Jafor Sadeek Quaderi"  :  ID-"2014-2-60-075"
///                "Pritam Datta"             :  ID-"2014-2-60-078"
///                "Mohd. Rasadin"            :  ID-"2014-2-60-039"
/// CSE- 375 (Compiler Design)
/// Section - 1
/// Group - 6
/// Reference- This Project Successfully Is Compiled On Visual Stdio 2017 of Fahim Shaharier Rasel's PC.


/// Declaring Necessary Header Files

#include<cstdio>
#include<cstring>
#include <iostream>
#include <stdlib.h>

using namespace std;

/// Declaring Few Variable Globally For Accessing With Functions

int top = -1;
char stack1[100];

int top2 = -1;
char stack2[100];


/// Declaring Functions Name

void push(char);
void pop();
void find_top();

void push2(char);
void pop2();
void find_top2();


int main()
{
    printf("..................................................................\n");
    printf("      Project Name- Lexical Error and Syntax Error Detection\n");
    printf("..................................................................\n\n");
    printf("This .cpp File Contains - Syntax Error Detection\n");
    printf(".........................\n\n");
    printf("Submitted By-\n");
    printf(".............\n");
    printf("              Shah Jafor Sadeek Quaderi  :  ID- 2014-2-60-075\n");
    printf("              Pritam Datta               :  ID- 2014-2-60-078\n");
    printf("              Mohd. Rasadin              :  ID- 2014-2-60-039\n\n");
    printf("CSE- 375 (Compiler Design)\n");
    printf("....\n");
    printf("Section - 1\n");
    printf(".........\n");
    printf("Group - 6\n");
    printf(".......\n");
    printf("Reference- This Project Successfully Is Compiled On Visual Studio 2017 of\n");
    printf(".......... Fahim Shaharier Rasel's PC\n\n\n");
    printf("- - - - - - - - - - - - - - - - - - - - - - - - - - -\n");
    printf("  Additional Information: Type 'end' for termination \n");
    printf("                          Type '*' To Complete Input   \n");
    printf("- - - - - - - - - - - - - - - - - - - - - - - - - - -\n\n");


    char a[100];        /// Declaring A String
    int flag_1= -1,     /// Declaring Flag_1 For Find Out 'printf' Existence In Input
        flag_2= -1,     /// Declaring Flag_2 For Find Out 'scanf' Existence In Input
        flag_3= -1,     /// Declaring Flag_2 For Find Out 'int main()' Existence In Input
        i;              /// i For Loop Accessing Values


/// Using Input As A Loop For Inputing Values From User

INPUT:

    printf("\n\n\n\n\n");
    printf("--------------------------------\n");
    printf("Enter Expression (or statement): \n");
    printf("--------------------------------\n\n");


    cin.get(a,100,'*');      /// Taking Input From User with 'Enter' And Ending Of Taking Input Is Executed By '*'
    printf("\n");
    printf("--------->>>>>>\n");

    if(strcmp(a,"end")==0)  /// Program Termination Condition
    {
        printf("\n\n");
        printf("Program Terminated\n\n");
        return 0;   /// Program Terminated And Returning 0
    }


    int stringLenght = strlen(a);   /// Assigning A Variable To Find Out The Size Inputed String Length



    /// Checking Parenthesis Error

    for (i = 0; i < stringLenght; i++)
    {
        if (a[i] == '(' || a[i] == '{' || a[i] == '[')
        {
            push(a[i]);     /// Push The Value Of a[i] To The Stack1 Array If The Value Is '(' Or '{'
        }
        else if (a[i] == ')' || a[i] == '}' || a[i] == ']')
        {
            pop();          /// Pop The Value Of a[i] From The Stack1 Array If The Value Is ')' Or '}'
        }
    }
    find_top();     /// Calling This Function To Show Result's Output Of Parenthesis Error's




    /// Checking Double Quotes Error

    for (i = 0; i < stringLenght; i++)
    {
        if ((a[i] == '"' && a[i-1] == '(') || (a[i-1] == '"' && a[i] == '%'))
        {
            push2(a[i]);    /// Push The Value Of a[i] To The Stack2 Array If The Values Are ('(' Or '"') and ('"' Or '%')
        }
        else if ((a[i-1] == '"' && a[i] == ')') || (a[i-1] == '"' && a[i] == ','))
        {
            pop2();         /// Pop The Value Of a[i] From The Stack2 Array If The Values Are ('"' Or ')') and ('"' Or ',')
        }
    }
    find_top2();    /// Calling This Function To Show Result's Output Of Double Quote Error's




    if(a[stringLenght-1] == ';' || a[stringLenght-2] == ';'  || a[stringLenght-3] == ';')
    {
        /// This checking only for error detection of semicolon (;) missing, it does not provide any output directly
    }
    else
    {
        printf("\nError found for ';' (semicolon)......\n\n");
    }



    for (i=0; i<stringLenght; i++)
    {
        if (a[i] == ')' && a[i+1] != ';' && (a[i+2] == 's' || a[i+2] == 'p' || a[i+2] == 'f' || a[i+2] == 'w'))
            /// Checking Semicolon (;) missing
        {
            printf("\nError found for ';' (semicolon)......\n\n");
        }
    }



    if(strcmp(a,"while") ==0 || strcmp(a,"if") ==0 || strcmp(a,"while;") ==0 || strcmp(a,"if;") ==0)
        /// Finding The Error On 'While' & 'If' Statement
    {
        printf("\nError for parenthesis missing......\n\n");
    }



    if(strcmp(a,"while();") ==0 || strcmp(a,"if();") ==0 ||
            strcmp(a,"for()") ==0  || strcmp(a,"for();") ==0 ||
            strcmp(a,"for(;);") ==0 || strcmp(a,"for(")==0)
        /// Finding The Error On 'While', 'If' & For (Loop) Statement
    {
        printf("\nError for missing primary expression......\n\n");
    }



    if(strcmp(a,"else")==0 || strcmp(a,"else if")==0 || strcmp(a,"else;")==0 ||
            strcmp(a,"else if;")==0 || strcmp(a,"else();")==0 || strcmp(a,"else if();")==0 ||
            strcmp(a,"else(;")==0 || strcmp(a,"else if(;")==0)

        /// Finding The Error On 'Else' & 'Else If' Statement
    {
        printf("Missing 'if' statement before......\n\n");
    }


    if(strcmp(a,"for")==0 || strcmp(a,"for(")==0)
        /// Finding The Error On 'For' (Loop Statement)
    {
        printf("\nError for parenthesis missing......\n\n");
        printf("\nError for missing primary expression......\n\n");
    }



    if(strcmp(a,"continue")==0 || strcmp(a,"continue;")==0 || strcmp(a,"break")==0 || strcmp(a,"break;")==0)
        /// Finding The Error On For 'Continue' & 'Break' Statement
    {
        printf("\nError for missing loop......\n\n");
    }



    if(strcmp(a,"while(1)") == 0 || strcmp(a,"for(;;)") == 0)
        /// Checking Infinite Loop On While & For
    {
        for(;;)
        {
            printf("Error ");
        }
    }



    for (i=0; i<stringLenght; i++)
    {
        if (a[i] == 'p' && a[i+1] == 'r' && a[i+2] == 'i' && a[i+3] == 'n' && a[i+4] == 't' && a[i+5] == 'f')
            /// Checking 'printf' Existence In Input
        {
            flag_1 = 1;
            break;
        }
        else if ((a[i] == 'P' && a[i+1] == 'r' && a[i+2] == 'i' && a[i+3] == 'n' && a[i+4] == 't' && a[i+5] == 'f') || ///Printf
                 (a[i] == 'P' && a[i+1] == 'r' && a[i+2] == 'i' && a[i+3] == 'n' && a[i+4] == 't') || ///Print
                 (a[i] == 'P' && a[i+1] == 'r' && a[i+2] == 'n' && a[i+3] == 't' && a[i+4] == 'f') || ///Prntf
                 (a[i] == 'P' && a[i+1] == 'r' && a[i+2] == 'i' && a[i+3] == 'n' && a[i+4] == 'f') || ///Prinf
                 (a[i] == 'P' && a[i+1] == 'r' && a[i+2] == 'n' && a[i+3] == 't' && a[i+4] == 'f') || ///Prntf
                 (a[i] == 'p' && a[i+1] == 'r' && a[i+2] == 'i' && a[i+3] == 'n' && a[i+4] == 't') || ///print
                 (a[i] == 'p' && a[i+1] == 'r' && a[i+2] == 'i' && a[i+3] == 'n' && a[i+4] == 'f') || ///prinf
                 (a[i] == 'P' && a[i+1] == 'r' && a[i+2] == 'n' && a[i+3] == 'f') || ///Prnf
                 (a[i] == 'p' && a[i+1] == 'r' && a[i+2] == 'n' && a[i+3] == 'f')) ///prnf
        {
            flag_1 = 0;
        }
    }



    for (i=0; i<stringLenght; i++)
    {
        if (a[i] == 's' && a[i+1] == 'c' && a[i+2] == 'a' && a[i+3] == 'n' && a[i+4] == 'f')
            /// Checking 'scanf' Existence In Input
        {
            flag_2 = 1;
            break;
        }
        else if ((a[i] == 'S' && a[i+1] == 'c' && a[i+2] == 'a' && a[i+3] == 'n' && a[i+4] == 'f') || ///Scanf
                 (a[i] == 'S' && a[i+1] == 'c' && a[i+2] == 'n' && a[i+3] == 'a' && a[i+4] == 'f') || ///Scnaf
                 (a[i] == 's' && a[i+1] == 'c' && a[i+2] == 'n' && a[i+3] == 'a' && a[i+4] == 'f') || ///scnaf
                 (a[i] == 'S' && a[i+1] == 'c' && a[i+2] == 'n' && a[i+3] == 'f') || ///Scnf
                 (a[i] == 'S' && a[i+1] == 'c' && a[i+2] == 'a' && a[i+3] == 'n') || ///Scan
                 (a[i] == 'S' && a[i+1] == 'a' && a[i+2] == 'n' && a[i+3] == 'f') || ///Sanf
                 (a[i] == 's' && a[i+1] == 'a' && a[i+2] == 'n' && a[i+3] == 'f') || ///sanf
                 (a[i] == 's' && a[i+1] == 'c' && a[i+2] == 'n' && a[i+3] == 'f') || ///scnf
                 (a[i] == 's' && a[i+1] == 'c' && a[i+2] == 'a' && a[i+3] == 'n') || ///scan
                 (a[i] == 'S' && a[i+1] == 'n' && a[i+2] == 'f') || ///Snf
                 (a[i] == 's' && a[i+1] == 'n' && a[i+2] == 'f')) ///snf
        {
            flag_2 = 0;
        }
    }



    for (i=0; i<stringLenght; i++)
    {
        if ((a[i] == 'i' && a[i+1] == 'n' && a[i+2] == 't' && a[i+3] == ' ' && a[i+4] == 'm'
            && a[i+5] == 'a' && a[i+6] == 'i' && a[i+7] == 'n' && a[i+8] == '('
            && a[i+9] == ')') ||
            (a[i] == 'v' && a[i+1] == 'o' && a[i+2] == 'i' && a[i+3] == 'd' && a[i+4] == ' '
            && a[i+5] == 'm' && a[i+6] == 'a' && a[i+7] == 'i' && a[i+8] == 'n'
            && a[i+9] == '(' && a[i+10] == ')'))
            /// Checking 'int main() / void main()' Existence In Input
        {
            flag_3 = 1;
            break;
        }
        else if ((a[i] == 'i' && a[i+1] == 'n' && a[i+2] == 't' && a[i+3] == ' ' && a[i+4] == 'm' &&
                  a[i+5] == 'a' && a[i+6] == 'i' && a[i+7] == 'n') ||  /// int main
                  (a[i] == 'v' && a[i+1] == 'o' && a[i+2] == 'i' && a[i+3] == 'd' && a[i+4] == ' ' &&
                  a[i+5] == 'm' && a[i+6] == 'a' && a[i+7] == 'i' && a[i+8] == 'n') ||  /// void main
                 (a[i] == 'v' && a[i+1] == 'i' && a[i+2] == 'd' && a[i+3] == ' ' && a[i+4] == 'm' &&
                  a[i+5] == 'a' && a[i+6] == 'i' && a[i+7] == 'n') ||  /// vid main
                 (a[i] == 'i' && a[i+1] == 'n' && a[i+2] == 't' && a[i+3] == ' ' && a[i+4] == 'm' &&
                  a[i+5] == 'a' && a[i+6] == 'n') ||  /// int man
                 (a[i] == 'm' && a[i+1] == 'a' && a[i+2] == 'i' && a[i+3] == 'n')) /// main
        {
            flag_3 = 0;
        }
    }



    if(flag_1 == 0)     /// Checking The Missing Of 'printf'
    {
        printf("\nError for missing 'printf'......\n\n");
    }



    if(flag_2 == 0)     /// Checking The Missing Of 'scanf'
    {
        printf("\nError for missing 'scanf'......\n\n");
    }



    if(flag_3 == 0)     /// Checking The Missing Of 'scanf'
    {
        printf("\nError in 'main()'......\n\n");
    }


    fflush(stdin);      /// Clearing The Buffer
    goto INPUT;         /// Go To Take Input Again


    printf("\n\n");
    return 0;           /// Terminating Program With Returning 0
}



void push(char a)       /// Push Function For Inserting "Parenthesis" Of Statement To Detect Error
{
    stack1[top] = a;
    top++;
}


void pop()              /// Pop Function For Removing "Parenthesis" Of Statement To Detect Error
{
    if (top == -1)
        ///     If top == -1, That Means There Is Error On "Parenthesis"
    {
        printf("\nExpression is invalid for parenthesis......\n\n");
        exit(0);    /// Exiting Form Pop Function
    }
    else
        ///     If Here top != -1, Decreasing The Value Of top
    {
        top--;
    }
}


void find_top()
{
    if (top != -1)
        ///     If top != -1, That Means There Is Error On "Parenthesis"
    {
        printf("\nExpression is invalid for parenthesis......\n\n");
    }
}


void push2(char a)      /// Push2 Function For Inserting "Double Quotes" Of Statement To Detect Error
{
    stack2[top2] = a;
    top2++;
}


void pop2()             /// pop2 Function For Removing "Double Quotes" Of Statement To Detect Error
{
    if (top2 == -1)
        ///     If top2 == -1, That Means There Is Error On "Double Quotes"
    {
        printf("\nExpression is invalid for double quotes......\n\n");
        exit(0);        /// Exiting Form Pop2 Function
    }
    else
        ///     If Here top2 != -1, Decreasing The Value Of top2
    {
        top2--;
    }
}


void find_top2()
{
    if (top2 != -1)
        ///     If top2 != -1, That Means There Is Error On "Double Quotes"
    {
        printf("\nExpression is invalid for double quotes......\n\n");
    }
}
